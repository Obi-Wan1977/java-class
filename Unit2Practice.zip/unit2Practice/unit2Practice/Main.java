package unit2Practice;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
		// TODO Auto-generated method stub
    	// Create a Scanner object for reading input
        Scanner scanner = new Scanner(System.in);

        // Task 1: Declare a boolean variable called canVote and assign it an appropriate value
        boolean canVote = true; // assuming the person is eligible to vote

        // Task 2: Declare two int variables and assign values of your choice
        System.out.print("Enter the first integer value: ");
        int value1 = scanner.nextInt();

        System.out.print("Enter the second integer value: ");
        int value2 = scanner.nextInt();

        // Write a conditional statement to test whether the two values are equal
        if (value1 == value2) {
            System.out.println("true");
        } else {
            System.out.println("false");
        }

        // Task 3: Declare 2 int variables and assign them an int value between 1 and 999
        System.out.print("Enter the first number between 1 and 999: ");
        int num1 = scanner.nextInt();

        System.out.print("Enter the second number between 1 and 999: ");
        int num2 = scanner.nextInt();

        // Write conditional statements to output which value is larger
        if (num1 > num2) {
            System.out.println(num1 + " is larger.");
        } else if (num2 > num1) {
            System.out.println(num2 + " is larger.");
        } else {
            System.out.println("Both numbers are equal.");
        }

        // Task 4: Declare another int variable and assign it an int value between 1 and 999
        System.out.print("Enter a third number between 1 and 999: ");
        int num3 = scanner.nextInt();

        // Write conditional statements to output which value is in the middle
        if ((num1 < num3 && num3 < num2) || (num2 < num3 && num3 < num1)) {
            System.out.println(num3 + " is in the middle.");
        } else {
            System.out.println(num3 + " is not in the middle.");
        }

        // Task 5: Declare a variable called selection with the value of 2
        System.out.print("Enter your color selection (1 for Yellow, 2 for Blue, 3 for Red): ");
        int selection = scanner.nextInt();

        // Use a switch statement to display the color based on the selection
        switch (selection) {
            case 1:
                System.out.println("The color is yellow.");
                break;
            case 2:
                System.out.println("The color is blue.");
                break;
            case 3:
                System.out.println("The color is red.");
                break;
            default:
                System.out.println("The selection was invalid.");
                break;
        }

        // Close the scanner
        scanner.close();
    }
}
