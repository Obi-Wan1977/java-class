package unit1Practice;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "John Doe";
	    int age = 30;
	    char theCharacter = 'A';
	    double interestRate = 0.05;
	    System.out.println("Name: " + name);
	    System.out.println("Age: " + age);
	    System.out.println("Character: " + theCharacter);
	    System.out.println("Interest Rate: " + interestRate);
	    Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter a value: ");
	    String userInput = scanner.nextLine();
	    String theName = "";
	    System.out.print("Enter your name: ");
	    theName = scanner.nextLine();
	    System.out.print("Enter your age: ");
	    int theAge = scanner.nextInt();
	    int blinks = 200;
	    int minutes = 7;
	    double blinksPerMinute = (double) blinks / minutes;
	    System.out.print("Enter an account balance: ");
	    double accountBalance = scanner.nextDouble();
	    System.out.printf("Account balance: %.2f\n", accountBalance);
	    System.out.println("User Input: " + userInput);
	    System.out.println("Your name: " + theName);
	    System.out.println("Your age: " + theAge);
	    System.out.println("Blinks per minute: " + blinksPerMinute);
	}

}
