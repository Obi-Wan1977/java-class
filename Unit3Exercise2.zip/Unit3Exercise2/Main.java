import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object for input
        Scanner scanner = new Scanner(System.in);

        // Ask the user for a number between 100 and 999
        System.out.print("Enter a number between 100 and 999: ");
        int num = scanner.nextInt();

        // Check if the input is within the valid range
        if (num < 100 || num > 999) {
            System.out.println("Please enter a number between 100 and 999.");
        } else {
            // Use a for loop to print numbers divisible by 13 up to the entered number
            for (int i = 1; i <= num; i++) {
                if (i % 13 == 0) {
                    System.out.println(i);
                }
            }
        }

        // Close the scanner to prevent resource leak
        scanner.close();
    }
}