
public class main {

    public static void main(String[] args) {
        // First array
        String[] games = {"Fortnite", "GTA 5", "Minecraft", "Poppy Playtime"};
        
        // Modify the third element
        games[2] = "Call Of Duty";
        
        // Print the first array
        for (int i = 0; i < games.length; i++) {
            System.out.println(games[i]);
        }

        // Second array
        String[] games1 = {"Fortnite", "GTA 5", "Minecraft", "Call Of Duty", "Poppy Playtime"};
        
        // Print the second array
        for (int i = 0; i < games1.length; i++) {
            System.out.println(games1[i]);
        }
    }
}