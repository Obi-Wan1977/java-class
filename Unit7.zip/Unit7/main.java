import java.util.Random;

// Enum to represent the fruits
enum Fruit {
    ORANGE, LEMON, CHERRY
}

public class main {
    // Instance variable to store the current fruit in the slot
    private Fruit fruit;

    // Constructor to initialize the Slot with a specific fruit
    public main(Fruit fruit) {
        this.fruit = fruit;
    }

    // Getter for the fruit
    public Fruit getFruit() {
        return fruit;
    }

    // Setter for the fruit
    public void setFruit(Fruit fruit) {
        this.fruit = fruit;
    }

    // Method to spin the slot, assigning a random fruit value
    public void spin() {
        Random rand = new Random();
        int randomIndex = rand.nextInt(Fruit.values().length);  // Random index between 0 and 2
        this.fruit = Fruit.values()[randomIndex];  // Set the fruit to a random one
    }

    // Override the toString method to return the name of the fruit
    @Override
    public String toString() {
        return "Slot: " + fruit;
    }

    public static void main(String[] args) {
        // Create a Slot object with an initial fruit (e.g., ORANGE)
        main slot = new main(Fruit.ORANGE);

        // Print the initial state of the slot
        System.out.println(slot);

        // Spin the slot and print the result
        slot.spin();
        System.out.println("After spinning: " + slot);
    }
}
