package unit1exercise2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		    Scanner input = new Scanner(System.in);
		    System.out.print("Enter the client's business name: ");
		    String clientName = input.nextLine();
		    System.out.print("Enter the total number of hours worked: ");
		    int hoursWorked = Integer.parseInt(input.nextLine());
		    double rate = 30.65;
		    double total = hoursWorked * rate;
		    System.out.println("\nBrianna Watt DBA Watt Gives");
		    System.out.println("Invoice for " + clientName);
		    System.out.println("Hours: " + hoursWorked);
		    System.out.println("Rate: $" + rate);
		    System.out.println("Total: $" + total);
		  }
	}
