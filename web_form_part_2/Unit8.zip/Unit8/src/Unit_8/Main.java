package Unit_8;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        SlotMachine machine = new SlotMachine();

        System.out.println("Initial state:");
        System.out.println(machine);

        System.out.println("\nSpinning...\n");
        machine.spin();

        System.out.println("Result:");
        System.out.println(machine);
    }
}

class Slot {
    private String fruit;
    private static final String[] FRUITS = {"cherry", "lemon", "orange"};
    private static final Random rand = new Random();

    public Slot(String fruit) {
        this.fruit = fruit;
    }

    public void spin() {
        this.fruit = FRUITS[rand.nextInt(FRUITS.length)];
    }

    public String getFruit() {
        return fruit;
    }

    public void setFruit(String fruit) {
        this.fruit = fruit;
    }

    @Override
    public String toString() {
        return fruit;
    }
}

class SlotMachine {
    private Slot slot1;
    private Slot slot2;
    private Slot slot3;

    public SlotMachine() {
        this.slot1 = new Slot("orange");
        this.slot2 = new Slot("lemon");
        this.slot3 = new Slot("cherry");
    }

    public void spin() {
        slot1.spin();
        slot2.spin();
        slot3.spin();
    }

    @Override
    public String toString() {
        return "| " + slot1 + " | " + slot2 + " | " + slot3 + " |";
    }

    public Slot getSlot1() {
        return slot1;
    }

    public Slot getSlot2() {
        return slot2;
    }

    public Slot getSlot3() {
        return slot3;
    }

    public void setSlot1(Slot slot1) {
        this.slot1 = slot1;
    }

    public void setSlot2(Slot slot2) {
        this.slot2 = slot2;
    }

    public void setSlot3(Slot slot3) {
        this.slot3 = slot3;
    }
}