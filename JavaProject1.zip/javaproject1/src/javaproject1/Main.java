package javaproject1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);

        // Ask the user for their name and initials
        System.out.print("Please enter your name: ");
        String name = scanner.nextLine();
        
        System.out.print("Please enter your first initial: ");
        char firstInitial = scanner.next().charAt(0);
        
        System.out.print("Please enter your last initial: ");
        char lastInitial = scanner.next().charAt(0);

        // Ask for the two numbers
        System.out.print("Please enter a number: ");
        int num1 = scanner.nextInt();
        
        System.out.print("Please enter another number: ");
        int num2 = scanner.nextInt();

        // Perform the calculations
        int sum = num1 + num2;
        int difference = num1 - num2;
        int product = num1 * num2;
        double division = (double) num1 / num2;

        // Output the results
        System.out.println("\n" + name + "\t" + firstInitial + "" + lastInitial);
        System.out.println(num1 + " + " + num2 + " = " + sum);
        System.out.println(num1 + " - " + num2 + " = " + difference);
        System.out.println(num1 + " * " + num2 + " = " + product);
        System.out.printf(num1 + " / " + num2 + " = %.2f\n", division);

        // Close the scanner
        scanner.close();
    }

	}