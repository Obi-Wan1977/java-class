package unit1exercise1;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			   Scanner input = new Scanner(System.in);
			     System.out.print("Please enter your goal in number of sales: ");
			     int total = Integer.parseInt(input.nextLine());
			     System.out.print("How many days do you have to complete your goal? ");
			     int days = Integer.parseInt(input.nextLine());
			     double numberPerDay = (double) total / days;
			     System.out.println("You will need to make " + numberPerDay + " sales each day in order to reach your goal of " + total + " in " + days + " days");

}
}
