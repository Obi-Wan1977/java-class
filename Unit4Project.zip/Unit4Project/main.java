import java.util.Random;
import java.util.Scanner;

public class main {

    public static void main(String[] args) {
        // Step 1: Create the three arrays
        String[] adjectives = {"shiny", "hot", "hairy", "yellow", "fast", "cold", "brave", "silent"};
        String[] nounIdea = {"darkness", "thought", "prayer", "knowledge", "hole", "fear", "love", "hope"};
        String[] nounObject = {"plant", "wig", "repellant", "trap", "brick", "car", "snow", "pumpkin"};

        // Step 2: Ask the user for the number of product names
        Scanner scanner = new Scanner(System.in);
        System.out.print("How many product names do you want? ");
        int numProducts = scanner.nextInt();  // Read user input

        // Step 3: Generate random product names
        String[] productNames = new String[numProducts]; // Array to store product names
        Random random = new Random(); // Random object to generate random numbers

        for (int i = 0; i < numProducts; i++) {
            // Randomly pick values from each array
            String randomAdjective = adjectives[random.nextInt(adjectives.length)];
            String randomNounIdea = nounIdea[random.nextInt(nounIdea.length)];
            String randomNounObject = nounObject[random.nextInt(nounObject.length)];

            // Create the product name and store it in the array
            productNames[i] = randomAdjective + " " + randomNounIdea + " " + randomNounObject;
        }

        // Step 4: Output the product names
        System.out.println("The " + numProducts + " generated products!");
        System.out.println("-------------------------");
        for (String productName : productNames) {
            System.out.println(productName);
        }
    }
}