import java.util.Scanner;

class Main {

    public static void main(String[] args) {
    	// TODO Auto-generated method stub
        Scanner input = new Scanner(System.in);

        // Set the number to be guessed
        int number = 6;

        // Prompt the user to guess a number
        System.out.print("Guess a number between 1 and 10: ");
        
        // Read the user's guess
        int guess = Integer.parseInt(input.nextLine());

        // Check if the guess is too high, too low, or correct
        if (guess > number) {
            System.out.println("Too high");
        } else if (guess == number) {
            System.out.println("You got it!");
        } else {
            System.out.println("Too low");
        }

        // Close the scanner
        input.close();
    }
		

	}