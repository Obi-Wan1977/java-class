import java.util.Scanner;

class Main {
    public static void main(String[] args) {
    	// TODO Auto-generated method stub
        Scanner input = new Scanner(System.in);
        
        // Ask the user for the hour in military time (1-24)
        System.out.print("Enter the hour in military time (1-24): ");
        int hour = input.nextInt();

        // Check if the hour is within a valid range
        if (hour >= 18 && hour <= 24) {
            System.out.println("Good evening");
        } else if (hour >= 12 && hour < 18) {
            System.out.println("Good afternoon");
        } else if (hour >= 6 && hour < 12) {
            System.out.println("Good morning");
        } else if (hour >= 1 && hour < 6) {
            System.out.println("Good morning");
        } else {
            // If the hour isn't within a valid range (1-24), wish them a good day
            System.out.println("Good day");
        }

        // Close the scanner
        input.close();
    }
}
		
