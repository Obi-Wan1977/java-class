package unit1exercise3;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
        // Create a scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask for room dimensions and cost per square foot
        System.out.print("Enter the length of the room in feet: ");
        double length = scanner.nextDouble();
        
        System.out.print("Enter the width of the room in feet: ");
        double width = scanner.nextDouble();
        
        System.out.print("Enter the cost per square foot of tile: ");
        double costPerSqFt = scanner.nextDouble();

        // Calculate area of the room
        double area = length * width;

        // Calculate the total cost of tiling the room
        double totalCost = area * costPerSqFt;

        // Output the results
        System.out.println("\nThe room is " + area + " square feet.");
        System.out.printf("\nAt $%.2f per sq.ft., It will cost $%.2f to tile it.\n", costPerSqFt, totalCost);

        // Close the scanner
        scanner.close();
    }
}
