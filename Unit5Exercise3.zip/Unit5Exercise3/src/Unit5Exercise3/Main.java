// Package definition (for organization)
package Unit5Exercise3;

/**
 * Main class: The entry point of the program.
 * This class contains the `main` method where the execution begins.
 * It creates objects of different pirate-related classes, modifies their properties, 
 * and prints those properties to the console.
 */
public class Main {
    /**
     * Main method: The starting point of the program.
     * Here we create multiple objects for the classes Pirate, Ship, CrewMember, and TreasureChest.
     * Each object is initialized and their properties are printed to the console.
     *
     * @param args Command-line arguments (not used in this program).
     */
    public static void main(String[] args) {
        
        // Creating two Pirate objects
        Pirate firstPirate = new Pirate();   // First pirate object
        Pirate secondPirate = new Pirate();  // Second pirate object

        // Setting properties for the first pirate
        firstPirate.beardVolume = 5;
        firstPirate.missingLimbs = 1;

        // Setting properties for the second pirate
        secondPirate.beardVolume = 8;
        secondPirate.missingLimbs = 2;

        // Printing the properties of the first pirate
        System.out.println("First Pirate's Beard Volume: " + firstPirate.beardVolume);
        System.out.println("First Pirate's Missing Limbs: " + firstPirate.missingLimbs);

        // Printing the properties of the second pirate
        System.out.println("Second Pirate's Beard Volume: " + secondPirate.beardVolume);
        System.out.println("Second Pirate's Missing Limbs: " + secondPirate.missingLimbs);

        // Creating two Ship objects
        Ship firstShip = new Ship();   // First ship object
        Ship secondShip = new Ship();  // Second ship object

        // Setting properties for the first ship
        firstShip.shipName = "Black Pearl";
        firstShip.cannons = 20;

        // Setting properties for the second ship
        secondShip.shipName = "Flying Dutchman";
        secondShip.cannons = 30;

        // Printing the properties of the first ship
        System.out.println("\nFirst Ship's Name: " + firstShip.shipName);
        System.out.println("First Ship's Cannons: " + firstShip.cannons);

        // Printing the properties of the second ship
        System.out.println("Second Ship's Name: " + secondShip.shipName);
        System.out.println("Second Ship's Cannons: " + secondShip.cannons);

        // Creating two CrewMember objects
        CrewMember firstCrewMember = new CrewMember();   // First crew member object
        CrewMember secondCrewMember = new CrewMember();  // Second crew member object

        // Setting properties for the first crew member
        firstCrewMember.rank = "Captain";
        firstCrewMember.yearsOfService = 15;

        // Setting properties for the second crew member
        secondCrewMember.rank = "First Mate";
        secondCrewMember.yearsOfService = 10;

        // Printing the properties of the first crew member
        System.out.println("\nFirst Crew Member's Rank: " + firstCrewMember.rank);
        System.out.println("First Crew Member's Years of Service: " + firstCrewMember.yearsOfService);

        // Printing the properties of the second crew member
        System.out.println("Second Crew Member's Rank: " + secondCrewMember.rank);
        System.out.println("Second Crew Member's Years of Service: " + secondCrewMember.yearsOfService);

        // Creating two TreasureChest objects
        TreasureChest firstChest = new TreasureChest();   // First treasure chest object
        TreasureChest secondChest = new TreasureChest();  // Second treasure chest object

        // Setting properties for the first treasure chest
        firstChest.goldAmount = 1000;
        firstChest.gemCount = 50;

        // Setting properties for the second treasure chest
        secondChest.goldAmount = 2000;
        secondChest.gemCount = 30;

        // Printing the properties of the first treasure chest
        System.out.println("\nFirst Chest's Gold Amount: " + firstChest.goldAmount);
        System.out.println("First Chest's Gem Count: " + firstChest.gemCount);

        // Printing the properties of the second treasure chest
        System.out.println("Second Chest's Gold Amount: " + secondChest.goldAmount);
        System.out.println("Second Chest's Gem Count: " + secondChest.gemCount);
    }
}

/**
 * Pirate class: Represents a pirate in the pirate organization.
 * The class contains two properties: `beardVolume` and `missingLimbs`,
 * which describe the physical characteristics of a pirate.
 */
class Pirate {
    public int beardVolume;  // The volume of the pirate's beard
    public int missingLimbs; // The number of limbs the pirate is missing
}

/**
 * Ship class: Represents a pirate ship.
 * The class contains two properties: `shipName` and `cannons`,
 * which describe the name of the ship and the number of cannons it has.
 */
class Ship {
    public String shipName; // The name of the pirate ship
    public int cannons;     // The number of cannons the ship has
}

/**
 * CrewMember class: Represents a crew member in the pirate organization.
 * The class contains two properties: `rank` and `yearsOfService`,
 * which describe the crew member's rank and how many years they have been serving.
 */
class CrewMember {
    public String rank;          // The rank of the crew member (e.g., Captain, First Mate)
    public int yearsOfService;   // The number of years the crew member has served
}

/**
 * TreasureChest class: Represents a chest containing treasure.
 * The class contains two properties: `goldAmount` and `gemCount`,
 * which describe the amount of gold and the number of gems in the chest.
 */
class TreasureChest {
    public int goldAmount;  // The amount of gold in the chest
    public int gemCount;    // The number of gems in the chest
}
