package Unit5Exercise2;

public class Main {
    public static void main(String[] args) {
        // Creating two Pirate objects
        Pirate firstPirate = new Pirate();
        Pirate secondPirate = new Pirate();

        firstPirate.beardVolume = 5;
        firstPirate.missingLimbs = 1;

        secondPirate.beardVolume = 8;
        secondPirate.missingLimbs = 2;

        // Printing the Pirate objects' properties
        System.out.println("First Pirate's Beard Volume: " + firstPirate.beardVolume);
        System.out.println("First Pirate's Missing Limbs: " + firstPirate.missingLimbs);

        System.out.println("Second Pirate's Beard Volume: " + secondPirate.beardVolume);
        System.out.println("Second Pirate's Missing Limbs: " + secondPirate.missingLimbs);

        // Creating two Ship objects
        Ship firstShip = new Ship();
        Ship secondShip = new Ship();

        firstShip.shipName = "Black Pearl";
        firstShip.cannons = 20;

        secondShip.shipName = "Flying Dutchman";
        secondShip.cannons = 30;

        // Printing the Ship objects' properties
        System.out.println("\nFirst Ship's Name: " + firstShip.shipName);
        System.out.println("First Ship's Cannons: " + firstShip.cannons);

        System.out.println("Second Ship's Name: " + secondShip.shipName);
        System.out.println("Second Ship's Cannons: " + secondShip.cannons);

        // Creating two CrewMember objects
        CrewMember firstCrewMember = new CrewMember();
        CrewMember secondCrewMember = new CrewMember();

        firstCrewMember.rank = "Captain";
        firstCrewMember.yearsOfService = 15;

        secondCrewMember.rank = "First Mate";
        secondCrewMember.yearsOfService = 10;

        // Printing the CrewMember objects' properties
        System.out.println("\nFirst Crew Member's Rank: " + firstCrewMember.rank);
        System.out.println("First Crew Member's Years of Service: " + firstCrewMember.yearsOfService);

        System.out.println("Second Crew Member's Rank: " + secondCrewMember.rank);
        System.out.println("Second Crew Member's Years of Service: " + secondCrewMember.yearsOfService);

        // Creating two TreasureChest objects
        TreasureChest firstChest = new TreasureChest();
        TreasureChest secondChest = new TreasureChest();

        firstChest.goldAmount = 1000;
        firstChest.gemCount = 50;

        secondChest.goldAmount = 2000;
        secondChest.gemCount = 30;

        // Printing the TreasureChest objects' properties
        System.out.println("\nFirst Chest's Gold Amount: " + firstChest.goldAmount);
        System.out.println("First Chest's Gem Count: " + firstChest.gemCount);

        System.out.println("Second Chest's Gold Amount: " + secondChest.goldAmount);
        System.out.println("Second Chest's Gem Count: " + secondChest.gemCount);
    }
}

// Pirate class
class Pirate {
    public int beardVolume;
    public int missingLimbs;
}

// Ship class
class Ship {
    public String shipName;
    public int cannons;
}

// CrewMember class
class CrewMember {
    public String rank;
    public int yearsOfService;
}

// TreasureChest class
class TreasureChest {
    public int goldAmount;
    public int gemCount;
}