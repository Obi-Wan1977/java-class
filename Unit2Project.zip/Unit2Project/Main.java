import java.util.Scanner;

class Main {
    public static void main(String[] args) {
    	// TODO Auto-generated method stub
        // Declare the cost for each fixin
        double yogurtCost = 1.00;
        double tomatoCost = 0.50;
        double lettuceCost = 0.30;
        double skittlesCost = 0.75;

        // Create a scanner object for user input
        Scanner input = new Scanner(System.in);

        // Prompt the cashier to enter the toppings
        System.out.print("Please enter first topping: ");
        String topping1 = input.nextLine().toLowerCase();

        System.out.print("Please enter second topping: ");
        String topping2 = input.nextLine().toLowerCase();

        System.out.print("Please enter third topping: ");
        String topping3 = input.nextLine().toLowerCase();

        // Initialize the total cost for toppings
        double totalCost = 0.0;

        // Add the cost of the first topping if it's valid
        if (topping1.equals("yogurt")) {
            totalCost += yogurtCost;
        } else if (topping1.equals("tomato")) {
            totalCost += tomatoCost;
        } else if (topping1.equals("lettuce")) {
            totalCost += lettuceCost;
        } else if (topping1.equals("skittles")) {
            totalCost += skittlesCost;
        }

        // Add the cost of the second topping if it's valid
        if (topping2.equals("yogurt")) {
            totalCost += yogurtCost;
        } else if (topping2.equals("tomato")) {
            totalCost += tomatoCost;
        } else if (topping2.equals("lettuce")) {
            totalCost += lettuceCost;
        } else if (topping2.equals("skittles")) {
            totalCost += skittlesCost;
        }

        // Add the cost of the third topping if it's valid
        if (topping3.equals("yogurt")) {
            totalCost += yogurtCost;
        } else if (topping3.equals("tomato")) {
            totalCost += tomatoCost;
        } else if (topping3.equals("lettuce")) {
            totalCost += lettuceCost;
        } else if (topping3.equals("skittles")) {
            totalCost += skittlesCost;
        }

        // Display the total cost of toppings
        System.out.printf("Your toppings cost $%.2f\n", totalCost);

        // Calculate and apply discount if applicable
        double discount = 0.0;
        if (totalCost >= 1.00) {
            discount = totalCost * 0.10; // 10% discount
            System.out.printf("You saved $%.2f!\n", discount);
        }

        // Calculate final total with discount
        double finalTotal = totalCost - discount;
        System.out.printf("Your total is $%.2f\n", finalTotal);

        // Close the scanner
        input.close();
    }

	}