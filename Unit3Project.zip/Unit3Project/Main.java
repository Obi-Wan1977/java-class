import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Initialize Scanner for user input
        Scanner scanner = new Scanner(System.in);
        
        // Greet the user
        System.out.println("Think of a number between 1 and 1000.");
        System.out.println("After each guess let the computer know if your number is higher (H), lower (L), or if it got it (G).");
        System.out.println("Press Enter and the computer will start guessing...");
        
        // Wait for the user to hit Enter before starting
        scanner.nextLine();

        // Initialize variables for binary search guessing
        int low = 1;
        int high = 1000;
        int guess = 0;
        String feedback = "";

        // While loop for the guessing process
        while (!feedback.equals("G")) {
            // Make the computer guess the middle number between low and high
            guess = (low + high) / 2;
            System.out.println("Beep-Boop, is your number " + guess + "?");

            // Get the user's feedback (H, L, G)
            feedback = scanner.nextLine().toUpperCase();

            // Adjust the guessing range based on feedback
            switch (feedback) {
                case "H": // too low
                    low = guess + 1; // Guess needs to be higher
                    break;
                case "L": // too high
                    high = guess - 1; // Guess needs to be lower
                    break;
                case "G": // got it
                    System.out.println("Got it!");
                    break;
                default:
                    System.out.println("Please enter H (higher), L (lower), or G (got it).");
                    break;
            }
        }

        // Ask the user to enter the number they thought of
        System.out.println("Enter the number you thought of to print the 'Hip-hip-hooray!' message:");
        int chosenNumber = scanner.nextInt();

        // For loop to print the "Hip-hip-hooray!" message
        for (int i = 1; i <= chosenNumber; i++) {
            System.out.println(i + " Hip-hip-hooray!");
        }

        // Close the scanner
        scanner.close();
    }
}