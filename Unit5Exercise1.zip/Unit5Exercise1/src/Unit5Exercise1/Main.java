package Unit5Exercise1;

public class Main {
    public static void main(String[] args) {
 
    }
}

class Pirate {
    public int beardVolume;
    public int missingLimbs;
}

class Ship {
    public String shipName;
    public int cannons;
}

class CrewMember {
    public String rank;
    public int yearsOfService;
}

class TreasureChest {
    public int goldAmount;
    public int gemCount;
}
