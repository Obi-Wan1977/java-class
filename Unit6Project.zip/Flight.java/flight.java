// Define the Flight class
public class flight {
    
    // Instance data
    private String shuttleName;
    private int missionNumber;
    private String originCity;
    private String originState;
    private int numOfPassengers;
    private String cargoType;

    // Constructor to initialize all attributes
    public flight(String shuttleName, int missionNumber, String originCity, String originState, int numOfPassengers, String cargoType) {
        this.shuttleName = shuttleName;
        this.missionNumber = missionNumber;
        this.originCity = originCity;
        this.originState = originState;
        this.numOfPassengers = numOfPassengers;
        this.cargoType = cargoType;
    }

    // Getter and setter methods for each attribute
    
    public String getShuttleName() {
        return shuttleName;
    }

    public void setShuttleName(String shuttleName) {
        this.shuttleName = shuttleName;
    }

    public int getMissionNumber() {
        return missionNumber;
    }

    public void setMissionNumber(int missionNumber) {
        this.missionNumber = missionNumber;
    }

    public String getOriginCity() {
        return originCity;
    }

    public void setOriginCity(String originCity) {
        this.originCity = originCity;
    }

    public String getOriginState() {
        return originState;
    }

    public void setOriginState(String originState) {
        this.originState = originState;
    }

    public int getNumOfPassengers() {
        return numOfPassengers;
    }

    public void setNumOfPassengers(int numOfPassengers) {
        this.numOfPassengers = numOfPassengers;
    }

    public String getCargoType() {
        return cargoType;
    }

    public void setCargoType(String cargoType) {
        this.cargoType = cargoType;
    }

    // Method to return a one-line description of the flight
    public String flightDescription() {
        return numOfPassengers + " Passengers\n" +
               "Mission " + missionNumber + "\n" +
               "Shuttle Name: " + shuttleName + "\n" +
               "Origin: " + originCity + ", " + originState + "\n" +
               "Cargo: " + cargoType + "\n" +
               "Passengers - " + numOfPassengers;
    }
}
