// Main class to test the Flight class
public class main {
    public static void main(String[] args) {
        // Create three different Flight objects
        flight flight1 = new flight("The Bottle Rocket", 547, "Akron", "Ohio", 74, "Candy");
        flight flight2 = new flight("Red Thunder", 421, "Los Angeles", "California", 100, "Electronics");
        flight flight3 = new flight("Mars Explorer", 782, "New York", "New York", 150, "Medical Supplies");

        // Change one attribute of the first flight using the set method
        flight1.setNumOfPassengers(80);

        // Get one attribute of flight2 and print it to the console
        System.out.println("Flight 2 Shuttle Name: " + flight2.getShuttleName());

        // Print the description for each flight using the method that returns a one-line description
        System.out.println("\nFlight 1 Description:");
        System.out.println(flight1.flightDescription());

        System.out.println("\nFlight 2 Description:");
        System.out.println(flight2.flightDescription());

        System.out.println("\nFlight 3 Description:");
        System.out.println(flight3.flightDescription());
    }
}